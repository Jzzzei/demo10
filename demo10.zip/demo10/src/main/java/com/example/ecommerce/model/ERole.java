package com.example.ecommerce.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
} 